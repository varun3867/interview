## Client example with Refresh tokens support

### Dependencies

To run this project, you must start the application located at `chapter-2/refresh-server`

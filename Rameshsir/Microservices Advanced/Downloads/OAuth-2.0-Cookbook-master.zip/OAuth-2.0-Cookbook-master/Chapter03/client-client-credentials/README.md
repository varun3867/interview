## Client example with Client Credentials grant type

### Dependencies

To run this project, you must start the application located at
`chapter-2/client-credentials-server`

package com.packt.example.clientpassword;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientPasswordApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientPasswordApplication.class, args);
	}
}

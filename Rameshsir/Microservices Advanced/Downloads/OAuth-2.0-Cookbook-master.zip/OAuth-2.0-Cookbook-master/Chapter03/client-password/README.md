## Client example with Resource Owner Password Credentials grant type

### Dependencies

To run this project, you must start the application located at `chapter-2/password-server`

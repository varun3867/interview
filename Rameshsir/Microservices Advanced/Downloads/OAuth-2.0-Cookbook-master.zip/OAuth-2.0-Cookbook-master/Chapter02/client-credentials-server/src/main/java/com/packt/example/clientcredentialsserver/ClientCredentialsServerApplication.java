package com.packt.example.clientcredentialsserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientCredentialsServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClientCredentialsServerApplication.class, args);
    }
}

# Scala Maven Skeleton project

I have created this project just to help building Scala projects with Maven.
The first motivation to do this was to create load tests with Gatling which counts on Scala, but as I've got more interested in learning Scala language through *Functional Programming with Scala* at Coursera, so I have decided to create this simple and small project.

To start coding with Scala, just import this project within your IDE (in my case I am using IntelliJ with respective Scala plugin).

package com.packt.example.oauth2provider.client;

public enum ClientType {

    PUBLIC, CONFIDENTIAL

}

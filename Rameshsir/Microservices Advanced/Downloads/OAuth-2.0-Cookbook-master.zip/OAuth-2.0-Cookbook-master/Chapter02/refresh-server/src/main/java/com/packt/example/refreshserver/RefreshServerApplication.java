package com.packt.example.refreshserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefreshServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefreshServerApplication.class, args);
	}
}

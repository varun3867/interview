## Google's discovery document
https://accounts.google.com/.well-known/openid-configuration

## Features presented by this recipe
- How to use Google's UserInfo endpoint (UserInfoService.java)
- Add `updateUserInfo` method to `OpenIdTokenServices` class

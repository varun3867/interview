package com.packt.example.googleuserinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoogleUserinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoogleUserinfoApplication.class, args);
	}
}

package com.packt.example.facebookloginoauth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacebookLoginOauth2Application {

	public static void main(String[] args) {
		SpringApplication.run(FacebookLoginOauth2Application.class, args);
	}
}

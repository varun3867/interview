# Recipe 1: Authenticating Google's users through Google OpenID Connect

https://console.developers.google.com/

To run this project you have to move `application.properties.sample` to `application.properties` and set up the application credentials (client_id and client_secret).
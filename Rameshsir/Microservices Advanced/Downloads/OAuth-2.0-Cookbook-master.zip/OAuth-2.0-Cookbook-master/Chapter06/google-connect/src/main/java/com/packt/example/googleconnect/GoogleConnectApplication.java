package com.packt.example.googleconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoogleConnectApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoogleConnectApplication.class, args);
	}
}

"In OAuth 2.0 in action, Sanso and Richer presents that If authorization server and protected 
resource conveys information about the user recently authenticated, we can build an authentication 
mechanism in top of OAuth 2.0 so the client can log the user in securely."


insert into user (login, password) values ('adolfo', '123');

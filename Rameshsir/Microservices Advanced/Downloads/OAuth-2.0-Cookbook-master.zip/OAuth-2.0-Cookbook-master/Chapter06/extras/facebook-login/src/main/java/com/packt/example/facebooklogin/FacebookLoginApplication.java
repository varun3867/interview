package com.packt.example.facebooklogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacebookLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacebookLoginApplication.class, args);
	}
}

package com.packt.example.openidspring5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenidSpring5Application {

	public static void main(String[] args) {
		SpringApplication.run(OpenidSpring5Application.class, args);
	}
}

# Adding support for OpenID Connect with Spring Security 5
This project isn't using `ClientRegistrationAutoConfiguration` class yet because at the moment there is no auto configuration available in Spring Boot.
Auto configuration for ClientRegistration is in progress through this PR: https://github.com/spring-projects/spring-boot/pull/10235


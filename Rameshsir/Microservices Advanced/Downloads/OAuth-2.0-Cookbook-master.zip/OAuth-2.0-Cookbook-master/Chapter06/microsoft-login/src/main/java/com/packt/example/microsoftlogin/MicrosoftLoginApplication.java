package com.packt.example.microsoftlogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicrosoftLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicrosoftLoginApplication.class, args);
	}
}

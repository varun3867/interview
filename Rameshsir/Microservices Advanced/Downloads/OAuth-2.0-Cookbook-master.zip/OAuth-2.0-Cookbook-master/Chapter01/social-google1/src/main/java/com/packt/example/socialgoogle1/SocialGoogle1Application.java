package com.packt.example.socialgoogle1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialGoogle1Application {

	public static void main(String[] args) {
		SpringApplication.run(SocialGoogle1Application.class, args);
	}
}

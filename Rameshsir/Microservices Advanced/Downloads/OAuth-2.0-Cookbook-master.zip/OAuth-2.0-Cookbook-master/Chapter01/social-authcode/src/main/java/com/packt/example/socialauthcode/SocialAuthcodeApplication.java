package com.packt.example.socialauthcode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialAuthcodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialAuthcodeApplication.class, args);
	}
}

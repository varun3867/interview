package com.packt.linkedin.example.sociallinkd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialLinkdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialLinkdApplication.class, args);
	}
}

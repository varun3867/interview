This project uses the following dependencies
- Web
- Security
- JPA
- MySQL


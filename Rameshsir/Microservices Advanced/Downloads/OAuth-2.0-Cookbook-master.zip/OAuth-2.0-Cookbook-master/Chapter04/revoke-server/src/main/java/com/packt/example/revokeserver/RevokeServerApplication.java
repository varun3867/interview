package com.packt.example.revokeserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevokeServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RevokeServerApplication.class, args);
	}
}

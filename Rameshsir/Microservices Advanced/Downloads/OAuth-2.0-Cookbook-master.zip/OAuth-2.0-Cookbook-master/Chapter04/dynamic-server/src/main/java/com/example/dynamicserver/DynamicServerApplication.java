package com.example.dynamicserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DynamicServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynamicServerApplication.class, args);
	}
}

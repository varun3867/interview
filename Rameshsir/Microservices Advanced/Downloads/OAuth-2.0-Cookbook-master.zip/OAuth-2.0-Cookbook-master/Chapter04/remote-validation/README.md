these projects use the following dependencies
- Web
- Security
- JPA
- MySQL

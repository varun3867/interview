package com.packt.example.remoteauthserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RemoteAuthserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(RemoteAuthserverApplication.class, args);
	}
}

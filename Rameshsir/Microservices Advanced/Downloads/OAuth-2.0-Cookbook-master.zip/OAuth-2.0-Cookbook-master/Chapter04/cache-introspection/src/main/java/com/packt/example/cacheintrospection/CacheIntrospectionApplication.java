package com.packt.example.cacheintrospection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CacheIntrospectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CacheIntrospectionApplication.class, args);
	}
}

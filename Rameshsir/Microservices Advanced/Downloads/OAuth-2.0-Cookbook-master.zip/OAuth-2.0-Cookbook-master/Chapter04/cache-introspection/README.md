# Commands
## Command for token instrospection
curl -X GET --user resource_server:abc123 "http://localhost:8080/oauth/check_token?token=26fcf872-a549-4742-a2ed-2f1afbd16f3d"
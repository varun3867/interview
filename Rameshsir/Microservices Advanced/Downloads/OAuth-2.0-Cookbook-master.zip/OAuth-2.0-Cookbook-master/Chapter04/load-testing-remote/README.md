# Scala Maven Skeleton project

I have created this project just to help building Scala projects with Maven.
The first motivation to do this was to create load tests with Gatling which counts on Scala, but as I've got more interested in learning Scala language through *Functional Programming with Scala* at Coursera, so I have decided to create this simple and small project.

To start coding with Scala, just import this project within your IDE (in my case I am using IntelliJ with respective Scala plugin).

## Having trouble importing to Eclipse Scala IDE?

If you have any problems related to cross compiler version go to `Project/Properties` and enable **Use Project Settings** option.
After enabling it, choose the appropriate Scala Installation which in the currently project version should be `Latest 2.11 bundle (dynamic)`.

package com.packt.example.pop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PopAuthServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PopAuthServerApplication.class, args);
	}
}

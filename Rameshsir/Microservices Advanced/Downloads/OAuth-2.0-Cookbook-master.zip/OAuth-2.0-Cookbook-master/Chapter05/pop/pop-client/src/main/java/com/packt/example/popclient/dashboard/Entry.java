package com.packt.example.popclient.dashboard;

public class Entry {

    private String value;

    public Entry(String value) {
        super();
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}

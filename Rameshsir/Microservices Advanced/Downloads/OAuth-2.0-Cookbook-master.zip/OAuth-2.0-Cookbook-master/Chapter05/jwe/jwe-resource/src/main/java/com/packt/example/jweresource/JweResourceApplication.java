package com.packt.example.jweresource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JweResourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JweResourceApplication.class, args);
	}
}

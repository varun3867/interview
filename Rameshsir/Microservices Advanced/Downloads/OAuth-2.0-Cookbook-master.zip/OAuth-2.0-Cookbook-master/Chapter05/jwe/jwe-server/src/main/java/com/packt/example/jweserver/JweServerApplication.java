package com.packt.example.jweserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JweServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JweServerApplication.class, args);
	}
}

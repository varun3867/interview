package com.packt.example.jwtasymmetricserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtAsymmetricServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtAsymmetricServerApplication.class, args);
	}
}

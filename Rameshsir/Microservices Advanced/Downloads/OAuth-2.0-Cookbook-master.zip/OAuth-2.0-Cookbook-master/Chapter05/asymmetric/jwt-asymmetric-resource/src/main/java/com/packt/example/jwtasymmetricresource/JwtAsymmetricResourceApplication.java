package com.packt.example.jwtasymmetricresource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtAsymmetricResourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtAsymmetricResourceApplication.class, args);
	}
}

insert into resource_owner (username, password, email)
values ('adolfo', '123', 'adolfo@mailinator.com');
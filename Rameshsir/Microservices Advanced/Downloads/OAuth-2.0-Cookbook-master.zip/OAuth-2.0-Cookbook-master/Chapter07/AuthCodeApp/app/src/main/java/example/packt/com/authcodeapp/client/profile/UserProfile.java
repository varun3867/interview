package example.packt.com.authcodeapp.client.profile;

public class UserProfile {

    private String name;
    private String email;

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

}
